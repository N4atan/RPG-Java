package rpg;

public class Villa extends Scene{
    public Villa(Player player){
        this.player = player;
        globalText = "O jogo começa em uma pequena vila chamada Erindale, que foi atacada por um grupo de goblins saqueadores. A fumaça sobe das casas em chamas, e você ouve gritos desesperados enquanto os moradores tentam se defender. Como herói, você precisa agir rapidamente.";

        barbaroText = "Você sente a fúria correr em suas veias ao ver a destruição. Sua força é sua maior arma, e com um rugido de guerra, você avança sem medo, atacando os goblins que ameaçam os moradores. Sua abordagem é direta, preferindo esmagar seus inimigos com força bruta.";

        ladinoText = "Você se esconde nas sombras, observando o caos. Sabendo que um ataque direto seria insensato, você procura a oportunidade perfeita para eliminar os goblins sem chamar atenção. Sua abordagem é furtiva e silenciosa.";

        hunterText = "Você está acostumado a rastrear criaturas e entender o terreno. No caos da vila, você analisa rapidamente a situação e posiciona suas armadilhas para conter o avanço dos goblins. Sua abordagem é estratégica."; 

        barbaroChoises = new String[] {
            "Investir contra o líder dos goblins", 
            "Defender os aldeões próximos"
        };

        ladinoChoises = new String[] {
            "Eliminar os batedores silenciosamente",
            "Encontrar uma rota de fuga para os aldeões"
        };

        hunterChoises = new String[] {
            "Colocar armadilhas na entrada da vila",
            "Usar sua furtividade para rastrear o chefe dos goblins"
        };

        afterBarbaroChoises = new String[] {
            //Ambos os casos inicia batalha.
            "Você avança em direção ao líder dos goblins, um guerreiro musculoso empunhando uma enorme clava. Com um grito que faz até mesmo alguns goblins recuarem, você ergue sua arma e desfere um golpe poderoso. O líder tenta bloquear, mas sua força supera a dele, lançando-o para trás. Ele se levanta cambaleante, pronto para um segundo round, mas você percebe que o restante do bando hesita, vendo sua determinação.",
            "Você usa sua força para erguer uma carroça virada e colocá-la como uma barricada. Os aldeões se abrigam atrás dela enquanto você enfrenta qualquer goblin que se aproxima. O combate será intenso, mas a barreira temporária permite que os moradores se organizem para contra-atacar ou fugir."
        };

        afterLadinoChoises = new String[] {
            "Você se move pelas sombras, sua adaga brilhando sob a luz das chamas. Voce ira eliminar os goblins batedores que estão distraídos observando a vila. Cada morte reduz a eficácia dos goblins, para que começem a parecer desorganizados."
        };
    }
}
